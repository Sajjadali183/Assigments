import java.util.Scanner;

class Task1{
  public static String reverseString(String str){
String reverse ="";
		for(int i=str.length()-1;i>=0;i--){
			reverse+= str.charAt(i);
		}
return reverse;

  }

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("Enter any word ");
		String str= in.nextLine();

		 String reverse=reverseString(str);
		

		System.out.print("Reversed : "+reverse);
	}
}