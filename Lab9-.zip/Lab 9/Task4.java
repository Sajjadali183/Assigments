class Task4{
	public static void countVowelsAndConsonants(String str){
		int vowel=0;
		int consonants=0;
		str = str.toLowerCase();

		for(int i=0;i<str.length();i++){
			char letter=str.charAt(i);
		
		if((letter>='a' && letter<='z')){

			if(letter=='a' || letter=='e' || letter=='i' || letter=='o'|| letter=='u' ){
				vowel++;
			}

			else{
				consonants++;
			}

		}
	}
			System.out.println("Total Vowels : "+vowel);
				System.out.println("Total Consonants : "+consonants);
	}

	public static void main(String[] args) {
		countVowelsAndConsonants("Misbah Ali Tunio");
	}

}