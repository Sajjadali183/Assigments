import java.util.Scanner;
class Lab3_Task1{
public static void main(String args []){
int num1=2;
int num2 =200;

for(int j=num1;j<=num2;j++){
boolean isPrime= true;
for(int i=2;i<j;i++){
if(j%i==0)
{
isPrime= false;
break;
}
}

if(isPrime)
{
System.out.println(j);
}
}






}
}