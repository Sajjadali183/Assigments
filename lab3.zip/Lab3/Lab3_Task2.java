
class Lab3_Task2{
public static void main(String[] args){
String text="aaabaaa";
String reversed="";
System.out.println(text);
for(int i=text.length()-1;i>=0;i--)
{
reversed= reversed+text.charAt(i);
}
System.out.print(reversed);
if(text.equals(reversed)){
System.out.print("  Palindrome  ");
}
else{
System.out.print("  Not palindrome ");
}


}
}