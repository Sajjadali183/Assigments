class Lab3_Task3{
public static void main(String []args){
int [][] matrix={{12,13,15,16},{11,110,121,17},{17,18,100,21}};

int sum_of_even=0;

for(int row=0;row<3;row++)
{
   for(int col=0;col<4;col++)
   {
     if(matrix[row][col]%2==0)
       {
         matrix[row][col]=matrix[row][col]/2;
       }
   }
}

for(int row=0;row<3;row++)
{
  for(int col=0;col<4;col++)
  {
     System.out.print(matrix[row][col]+"\t");
  }
      System.out.println(" ");
}

for(int row=0;row<3;row++)
{
  for(int col=0;col<4;col++)
  {
    if(matrix[row][col]%2!=0)
    {
       System.out.println("Odd numbers"+matrix[row][col]+" ");
    }
  }
}


for(int row=0;row<3;row++)
{
  for(int col=0;col<4;col++)
  {
    if(matrix[row][col]%2==0)
     {
       sum_of_even=sum_of_even+matrix[row][col];
     }
  }
}
System.out.println("Sum of even divide by 2 :"+sum_of_even);

}
}