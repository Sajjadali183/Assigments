class Main{
    public static void main(String args []){
    Dog sound = new Dog(" Tony ,", 4);
    sound.displayInfo();
    System.out.println();
    sound.makeSound();
        
    }
}