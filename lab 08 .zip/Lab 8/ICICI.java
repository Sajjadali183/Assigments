class ICICI extends Bank{
	@Override
	public double getInterest(){
		return 8.2;
	}
}