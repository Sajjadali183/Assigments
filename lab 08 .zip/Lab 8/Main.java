class Main{
	public static void main(String[] args) {
		Student s = new Student();
		 s.setName("Tunio");
		 s.setRollNumber(109);
		 s.setGrade('A');

		 s.displayInfo();
	}
}