class Overloaded{

	int add(int a, int b){
		return a+b;
	}

	double add(double a, double b){
		return a+b;
	}

	String add(String a, String b){
		return a+b;
	}

	public static void main(String[] args) {
		
		Overloaded cal= new Overloaded();
		System.out.println(cal.add(3,9));
System.out.println(cal.add(3.56,9.78));
System.out.println(cal.add("Hello","World"));

	}
}
