import java.util.Scanner;

class Lab2_Task4 {
    public static void main(String args[]) {
        Scanner input = new Scanner(System.in); 

        String[] names = new String[6]; 

        
        for (int i = 0; i < 6; i++) {
            System.out.println("Enter name " + (i + 1) + ":");
            names[i] = input.nextLine(); 
        }
        boolean foundAli = false;
        for (int j = 0; j < 6; j++) {
            if (names[j].equals("Ali")){ 
                foundAli = true;
                break; 
            }
        }

        if (foundAli) {
            System.out.println("Ali is present.");
        } else {
            System.out.println("Ali is not present.");
        }

        input.close();
    }
}