import java.util.Scanner;
	class Lab2_Task1{
public static void main(String[] args){

Scanner arr=new Scanner(System.in);
char const_arr[] = {'b','c','d','f','g','h','j','k','l','m','n','p','q','r','s','t','v','w','x','y','z'};
System.out.println("Enter values of array to find consonant = " );

char user_inp=arr.next().charAt(0);
boolean isConst=false;
for(int i=0;i<const_arr.length;i++)
{
if(user_inp==const_arr[i])
{
isConst=true;
break;
}
}
if(isConst)
{
System.out.print("It is a consonant ");
}
else
{
System.out.println("It is not a constant : ");
}
}

}


