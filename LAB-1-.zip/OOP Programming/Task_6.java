class Task_6{
public static void main(String args[]){
double pkr=2;
double dollar=278.6;
dollar=2*278.6;
System.out.println(" The ruppees in dollar : "+dollar);
}
}