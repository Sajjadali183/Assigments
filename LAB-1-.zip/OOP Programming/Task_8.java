class Task_8{
	public static void main(String args[]){
		double km=5;
	double mile;
  mile=5*1.6;
   km =mile/km;
	System.out.println("The distance in mile "+mile);
		System.out.println("The distance in kilometers "+km);
}
}
