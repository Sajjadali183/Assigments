class Task_7{
public static void main(String args[]){
double radius=3.6;
double height =6;
double pi=3.14;
double area;
area=pi*radius*radius*height;


System.out.println("Area of the circle is : "+area );
}
}