class Task_5{
public static void main(String args[]){
System.out.println("\t\t**********");
System.out.println("\t\t*\t *");
System.out.println("\t\t*\t *");
System.out.println("\t\t*\t *");
System.out.println("\t\t*\t *");
System.out.println("\t\t**********");
}
}