import java.util.Scanner;
class Task_9{
public static void main(String args[]){
Scanner Symbol=new Scanner(System.in);

int num1 = Symbol.nextInt();
System.out.println("Enter  num1:"+num1);

int num2 = Symbol.nextInt();
System.out.println("Enter  num2:"+num2);
System.out.println("Enter any sign(+,-,*,/ ) :");
char sign = Symbol.next().charAt(0);
if(sign=='+')
{
System.out.println("Addition = "+(num1+num2) );
}
else if(sign=='-')
{
System.out.println("Substraction = "+(num1-num2) );
}
else if(sign=='*')
{
System.out.println("Multiplication = "+(num1*num2) );
}
else if(sign=='/')
{
System.out.println("Division = "+(num1/num2) );
}
else 
{
System.out.println("Entered Sign not found ,Sorry !");
}
}
}
