class Task_3{
public static void main(String args[]){
String name="Musbah Ali ";
int age=20;
double GPA=3.67;
String gender="Male";
String Foreigner ="No";
System.out.println(name); 
System.out.println(age);
System.out.println(GPA);
System.out.println(gender);
System.out.println(Foreigner);
}
}